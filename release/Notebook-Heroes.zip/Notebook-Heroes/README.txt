Extract this ZIP, then double-click Game.html.
Open with Microsoft Edge or Google Chrome.
No installation or internet connection required.
