@echo off
start "" "%~dp0Game.html"
